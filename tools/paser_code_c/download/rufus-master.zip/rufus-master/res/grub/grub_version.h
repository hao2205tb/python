/*
 * This file contains the version string of the Grub4Dos 2.x binary embedded in Rufus.
 * Should be the same as the grub4dos_version file in the source Grub4Dos was compiled from.
 */
#define GRUB4DOS_VERSION "0.4.6a"
