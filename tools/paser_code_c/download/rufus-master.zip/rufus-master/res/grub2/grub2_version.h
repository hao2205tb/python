/*
 * This file contains the version string of the GRUB 2.x binary embedded in Rufus.
 * Should be the same as GRUB's PACKAGE_VERSION in config.h.
 */
#pragma once

#define GRUB2_PACKAGE_VERSION "2.06"
