# Reporting a Vulnerability

To report a vulnerability for Rufus, please e-mail support@akeo.ie.

If you find a vulnerability, we will ask you to respect [responsible disclosure](https://en.wikipedia.org/wiki/Responsible_disclosure) practices.

In return, we will endeavour to respond to vulnerability reports within 48 hours.
