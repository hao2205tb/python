/* placeholder for unused MMC helper routines. */

typedef driver_return_code_t (*mmc_run_cmd_fn_t) ( void );
